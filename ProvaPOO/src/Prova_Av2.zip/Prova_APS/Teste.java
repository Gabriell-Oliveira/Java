package Prova_APS;

public class Teste {

	public static void main(String[] args) {
		Biblioteca biblioteca = new Biblioteca();
				
		biblioteca.Menu();
	}	
}